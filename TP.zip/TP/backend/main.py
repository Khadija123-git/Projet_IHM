from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

import shutil
import os
import pandas as pd
import dask.dataframe as dd
import logging


app = FastAPI()

# Autoriser les requêtes du frontend (CORS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dossiers
UPLOAD_DIR = "uploaded_files"
OUTPUT_DIR = "output_files"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Variables globales
uploaded_file_path = ""
cleaned_file_path = ""

# Logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# Lecture de fichiers
def read_file(file_path: str) -> dd.DataFrame:
    extension = os.path.splitext(file_path)[1].lower()

    if extension == '.csv':
        return dd.read_csv(file_path, assume_missing=True, on_bad_lines='skip')
    elif extension in ['.xls', '.xlsx']:
        df = pd.read_excel(file_path)
        return dd.from_pandas(df, npartitions=1)
    elif extension == '.parquet':
        return dd.read_parquet(file_path)
    else:
        raise ValueError("Format de fichier non supporté.")

# Sauvegarde des données nettoyées
def save_cleaned_data(df: dd.DataFrame, file_format: str) -> str:
    file_name = f"cleaned_data.{file_format}"
    file_path = os.path.join(OUTPUT_DIR, file_name)

    if file_format == 'csv':
        df.to_csv(file_path, single_file=True)
    elif file_format == 'parquet':
        df.to_parquet(file_path)
    elif file_format == 'json':
        df.to_json(file_path, orient='records', lines=True)
    else:
        raise ValueError(f"Format de sauvegarde {file_format} non supporté.")

    return file_path

# Upload
@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    global uploaded_file_path
    file_extension = os.path.splitext(file.filename)[1].lower()
    allowed_extensions = ['.csv', '.xls', '.xlsx', '.parquet']

    if file_extension not in allowed_extensions:
        return JSONResponse(status_code=400, content={"error": "Format de fichier non supporté."})

    file_location = os.path.join(UPLOAD_DIR, file.filename)

    try:
        with open(file_location, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        uploaded_file_path = file_location
        logger.info(f"Fichier {file.filename} uploadé avec succès.")
        return {"filename": file.filename}
    except Exception as e:
        logger.error(f"Erreur upload : {str(e)}")
        return JSONResponse(status_code=500, content={"error": f"Erreur upload : {str(e)}"})

@app.get("/dataset_info")
async def get_dataset_info():
    global uploaded_file_path
    import os

    if not uploaded_file_path or not os.path.exists(uploaded_file_path):
        return JSONResponse(content={"error": "Aucun fichier trouvé"}, status_code=400)

    try:
        df = read_file(uploaded_file_path)

        nb_rows = int(df.shape[0].compute())
        nb_cols = int(df.shape[1])
        missing_values = df.isnull().sum().compute().to_dict()

        # Convertir en pandas juste pour les doublons
        df_pandas = df.compute()
        duplicated = int(df_pandas.duplicated().sum())

        return {
            "nb_rows": nb_rows,
            "nb_cols": nb_cols,
            "missing_values": missing_values,
            "duplicated": duplicated
        }

    except Exception as e:
        import traceback
        print("Erreur dans /dataset_info :", e)
        traceback.print_exc()
        return JSONResponse(content={"error": str(e)}, status_code=500)




# Obtenir les colonnes
@app.get("/columns")
async def get_columns():
    global uploaded_file_path
    if not uploaded_file_path:
        return JSONResponse(status_code=400, content={"error": "Aucun fichier n'a été uploadé."})
    try:
        df = read_file(uploaded_file_path)
        return {
            "columns": [
                {"name": col, "dtype": str(df[col].dtype)}
                for col in df.columns
            ]
        }
    except Exception as e:
        logger.error(f"Erreur lecture colonnes : {str(e)}")
        return JSONResponse(status_code=500, content={"error": str(e)})

# Statistiques
@app.get("/statistics")
async def statistics():
    global uploaded_file_path
    if not uploaded_file_path:
        return JSONResponse(status_code=400, content={"error": "Aucun fichier n'a été uploadé."})
    try:
        df = read_file(uploaded_file_path)
        numeric_df = df.select_dtypes(include=['number'])
        statistics = {
            "mean": numeric_df.mean().compute().to_dict(),
            "std_dev": numeric_df.std().compute().to_dict(),
            "count": numeric_df.count().compute().to_dict()
        }
        return {"statistics": statistics}
    except Exception as e:
        logger.error(f"Erreur stats : {str(e)}")
        return JSONResponse(status_code=500, content={"error": str(e)})

# Nettoyage
@app.post("/clean")
async def clean_data(format: str = Form('csv')):
    global uploaded_file_path, cleaned_file_path
    if not uploaded_file_path:
        return JSONResponse(status_code=400, content={"error": "Aucun fichier n'a été uploadé."})
    try:
        df = read_file(uploaded_file_path)
        df_dropna = df.dropna()
        df_filled = df.fillna({
            "passenger_count": 1,
            "trip_distance": 1.0,
            "fare_amount": 5.0
        })

        if "fare_amount" in df.columns and "trip_distance" in df.columns:
            df_filtered = df[(df["fare_amount"] >= 2) & (df["trip_distance"] >= 0.5)]
        else:
            df_filtered = df

        datetime_columns = ["tpep_pickup_datetime", "tpep_dropoff_datetime"]
        for col in datetime_columns:
            if col in df.columns:
                df[col] = dd.to_datetime(df[col], errors="coerce")

        df_cleaned = df_filtered.drop_duplicates().dropna()
        cleaned_file_path = save_cleaned_data(df_cleaned, format)

        # Récupération des infos clés
        count_rows = df_cleaned.shape[0].compute()
        count_cols = df_cleaned.shape[1]
        columns_info = []
        for col in df_cleaned.columns:
            dtype = str(df_cleaned[col].dtype)
            columns_info.append({"name": col, "dtype": dtype})
        sample = df_cleaned.head(5, compute=True).to_dict(orient="records")

        return {
            "message": "Nettoyage terminé avec succès.",
            "rows_after_cleaning": count_rows,
            "columns_count": count_cols,
            "columns": columns_info,
            "sample_data": sample,
            "saved_file_path": cleaned_file_path
        }
    except Exception as e:
        logger.error(f"Erreur nettoyage : {str(e)}")
        return JSONResponse(status_code=500, content={"error": str(e)})


@app.get("/trip-peaks")
async def get_trip_peaks():
    global cleaned_file_path
    if not cleaned_file_path:
        return JSONResponse(status_code=400, content={"error": "Fichier nettoyé introuvable."})

    try:
        # Chargement du fichier selon son type (CSV ou Parquet)
        if cleaned_file_path.endswith('.csv'):
            df = dd.read_csv(cleaned_file_path)
        elif cleaned_file_path.endswith('.parquet'):
            df = dd.read_parquet(cleaned_file_path)
        else:
            return JSONResponse(status_code=400, content={"error": "Format de fichier non supporté."})

        # Vérification que la colonne 'tpep_pickup_datetime' existe
        if "tpep_pickup_datetime" not in df.columns:
            return JSONResponse(status_code=400, content={"error": "Colonne 'tpep_pickup_datetime' non trouvée."})

        # Convertir la colonne 'tpep_pickup_datetime' en datetime et extraire l'heure de prise en charge
        df["pickup_hour"] = dd.to_datetime(df["tpep_pickup_datetime"], errors="coerce").dt.hour
        
        # Vérifier les valeurs manquantes dans la colonne "pickup_hour" et les exclure
        df_clean = df.dropna(subset=["pickup_hour"])

        # Comptage des trajets par heure de prise en charge
        trip_counts = df_clean.groupby("pickup_hour").size().compute()

        # Formatage des résultats sous forme de liste de dictionnaires
        result = trip_counts.reset_index().rename(columns={0: "trip_count"}).to_dict(orient="records")

        return {"trip_peaks": result}
    except Exception as e:
        logger.error(f"Erreur trip peaks : {str(e)}")
        return JSONResponse(status_code=500, content={"error": f"Une erreur s'est produite : {str(e)}"})




from fastapi.responses import FileResponse

@app.get("/download_cleaned")
async def download_cleaned():
    global cleaned_file_path
    if not cleaned_file_path or not os.path.exists(cleaned_file_path):
        return JSONResponse(status_code=404, content={"error": "Fichier nettoyé introuvable."})
    return FileResponse(cleaned_file_path, media_type='application/octet-stream', filename=os.path.basename(cleaned_file_path))

import React, { useState } from 'react';
import './App.css';
import UploadButton from './components/UploadButton';
import ActionButton from './components/ActionButton';
import ResultDisplay from './components/ResultDisplay';
import TripPeakChart from './components/TripPeakChart';

function App() {
  const [result, setResult] = useState(null);
  const [tripPeaks, setTripPeaks] = useState([]);

  const handleUpload = () => {
    setResult(null);
    setTripPeaks([]);
  };

  const handleResult = (data) => {
    if (data.trip_peaks) {
      setTripPeaks(data.trip_peaks);
    } else {
      setResult(data);
    }
  };

  return (
    <div className="app">
      <header className="header">
        <h1>NYC Taxi Analyzer</h1>
        <p className="subtitle">Visualize, clean, and analyze New York City taxi data</p>
      </header>

      <main className="main-content">
        <UploadButton onUploadSuccess={handleUpload} />

        {/* ✅ Boutons d’action */}
        <div className="action-buttons">
          <ActionButton endpoint="dataset_info" label="Dataset Info" onResult={handleResult} />
          <ActionButton endpoint="columns" label="Show Columns" onResult={handleResult} />
          <ActionButton endpoint="statistics" label="View Statistics" onResult={handleResult} />
          <ActionButton endpoint="clean" label="Clean Data" onResult={handleResult} />
          <ActionButton 
            endpoint="trip-peaks" 
            label="Visualization" 
            onResult={(data) => setTripPeaks(data.trip_peaks)} 
          />
        </div>

        {/* ✅ Affichage des résultats */}
        <div className="result-display">
          <ResultDisplay data={result} />
        </div>

        {/* ✅ Graphique */}
        {tripPeaks.length > 0 && (
          <div className="chart-section">
            <h2>Nombre de trajets par heure</h2>
            <TripPeakChart data={tripPeaks} />
          </div>
        )}
      </main>

      <footer className="footer">
        <p>© 2025 NYC Taxi Analyzer.</p>
      </footer>
    </div>
  );
}

export default App;






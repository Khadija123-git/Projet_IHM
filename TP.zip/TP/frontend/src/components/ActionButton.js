import React from 'react';
import axios from 'axios';
import './ActionButton.css';


const ActionButton = ({ endpoint, label, onResult }) => {
  const handleClick = async () => {
  try {
    const url = `http://localhost:8000/${endpoint}`;
    let response;
    if (endpoint === 'clean') {
      // Créer un form data avec format csv
      const formData = new FormData();
      formData.append('format', 'csv');
      response = await axios.post(url, formData);
    } else {
      response = await axios.get(url);
    }

    if (response.data.error) {
      alert(`Erreur: ${response.data.error}`);
    } else {
      onResult(response.data);
    }
  } catch (error) {
    alert(`Erreur lors de la requête vers /${endpoint}: ${error.response ? error.response.data : error.message}`);
    console.error('Erreur complète:', error);
  }
};

  return (
    <button onClick={handleClick} className="action-button">
      {label}
    </button>
  );
};

export default ActionButton;

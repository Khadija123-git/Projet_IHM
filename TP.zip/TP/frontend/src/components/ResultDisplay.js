import React from 'react';
import './ResultDisplay.css';

const StatTable = ({ title, data }) => (
  <>
    <h4 className="stat-title">{title}</h4>
    <div className="table-scroll">
      <table className="styled-table">
        <thead>
          <tr><th>Colonne</th><th>Valeur</th></tr>
        </thead>
        <tbody>
          {Object.entries(data).map(([key, value]) => (
            <tr key={key}>
              <td>{key}</td>
              <td>{Number(value).toFixed(3)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </>
);

const SampleTable = ({ data }) => {
  if (!data || data.length === 0) return <p className="no-data">Aucune donnée à afficher.</p>;

  return (
    <div className="sample-table-wrapper">
      <div className="table-scroll">
        <table className="styled-table">
          <thead>
            <tr>
              {Object.keys(data[0]).map((col) => (
                <th key={col} className="truncate">{col}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, idx) => (
              <tr key={idx}>
                {Object.values(row).map((val, i) => (
                  <td key={i} className="truncate">
                    {val === null || val === undefined ? '-' : String(val)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const ResultDisplay = ({ data }) => {
  if (!data) return null;

  if (data.error) {
    return <p className="error-text">Erreur : {data.error}</p>;
  }

  if (data.message && data.sample_data) {
    return (
      <div className="section">
        <h3>{data.message}</h3>
        <p><strong>Nombre de lignes après nettoyage :</strong> {data.rows_after_cleaning}</p>
        <p><strong>Nombre de colonnes :</strong> {data.columns_count}</p>
        <p><strong>Chemin du fichier nettoyé :</strong> {data.saved_file_path}</p>
        <h4 className="sub-title">Exemple de données nettoyées :</h4>
        <SampleTable data={data.sample_data} />
      </div>
    );
  }

  if (data.columns && data.columns.length > 0) {
    const isObject = typeof data.columns[0] === 'object';

    return (
      <div className="table-scroll">
        <table className="styled-table top-margin">
          <thead>
            <tr>
              <th>Nom de la colonne</th>
              {isObject && <th>Type de données</th>}
            </tr>
          </thead>
          <tbody>
            {data.columns.map((col, idx) => (
              <tr key={idx}>
                <td>{isObject ? col.name : col}</td>
                {isObject && <td>{col.dtype}</td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  if (data.statistics) {
    const stats = data.statistics;
    return (
      <div className="section">
        <h3>Statistiques numériques</h3>
        {Object.entries(stats).map(([statName, statData]) => (
          <StatTable key={statName} title={statName} data={statData} />
        ))}
      </div>
    );
  }

  if (
    (data.nb_rows !== undefined || data.total_rows !== undefined) &&
    (data.nb_cols !== undefined || data.total_cols !== undefined) &&
    (data.duplicated !== undefined || data.duplicates !== undefined) &&
    data.missing_values
  ) {
    const rows = data.nb_rows ?? data.total_rows;
    const cols = data.nb_cols ?? data.total_cols;
    const dups = data.duplicated ?? data.duplicates;

    return (
      <div className="section">
        <h3>Informations générales sur le dataset</h3>
        <div className="table-scroll">
          <table className="styled-table">
            <thead>
              <tr>
                <th>Catégorie</th>
                <th>Valeur</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Nombre total de lignes</td>
                <td>{rows.toLocaleString()}</td>
              </tr>
              <tr>
                <td>Nombre total de colonnes</td>
                <td>{cols}</td>
              </tr>
              <tr>
                <td>Nombre de doublons</td>
                <td>{dups}</td>
              </tr>
              <tr>
                <td colSpan="2" className="missing-header">Valeurs manquantes par colonne</td>
              </tr>
              {Object.entries(data.missing_values).map(([col, count]) => (
                <tr key={col}>
                  <td>{col}</td>
                  <td>{count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  return (
    <div className="json-section">
      <h3>Résultat :</h3>
      <pre>{JSON.stringify(data, null, 2)}</pre>
    </div>
  );
};

export default ResultDisplay;



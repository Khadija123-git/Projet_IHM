import React, { useRef } from 'react';
import html2canvas from 'html2canvas';
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';

const TripPeakChart = ({ data }) => {
  const chartRef = useRef();

  // Si aucune donnée n'est passée ou elle est vide, on ne rend rien
  if (!data || data.length === 0) return <p>Aucune donnée à afficher</p>;

  // Tri des données par heure
  const sortedData = [...data].sort((a, b) => a.pickup_hour - b.pickup_hour);

  const handleDownload = () => {
    // Utilisation de html2canvas pour créer une image du graphique
    html2canvas(chartRef.current).then(canvas => {
      const link = document.createElement('a');
      link.download = 'trip-peaks-chart.png';
      link.href = canvas.toDataURL();
      link.click();
    });
  };

  return (
    <div style={{ marginTop: '30px' }}>
      <h3>Trajets par heure de la journée</h3>
      <div ref={chartRef} style={{ backgroundColor: 'white', padding: '10px' }}>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={sortedData}>
            <CartesianGrid stroke="#ccc" />
            <XAxis 
              dataKey="pickup_hour" 
              label={{ value: 'Heure', position: 'insideBottomRight', offset: -5 }} 
              tickFormatter={(hour) => `${hour}h`} 
            />
            <YAxis 
              label={{ value: 'Nombre de trajets', angle: -90, position: 'insideLeft' }} 
            />
            <Tooltip />
            <Bar dataKey="trip_count" fill="#8884d8" animationDuration={800} />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <button onClick={handleDownload} style={{ marginTop: '10px' }}>
        Télécharger le graphique
      </button>
    </div>
  );
};

export default TripPeakChart;




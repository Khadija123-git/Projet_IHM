import React from 'react';
import axios from 'axios';
import './UploadButton.css';


const UploadButton = ({ onUploadSuccess }) => {
  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      // Envoie la requête avec les bonnes options dans axios
      await axios.post('http://localhost:8000/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      alert("Fichier uploadé avec succès !");
      onUploadSuccess();
    } catch (error) {
      alert("Erreur lors de l'upload du fichier.");
      console.error(error);
    }
  };

  return (
    <div>
      <input type="file" accept=".csv,.xlsx,.xls,.parquet" onChange={handleFileChange} />
    </div>
  );
};

export default UploadButton;


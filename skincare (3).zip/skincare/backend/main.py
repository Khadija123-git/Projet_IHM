# backend/main.py
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import uvicorn

app = FastAPI()

# ----------------- Chargement des données ------------------
try:
    df = pd.read_csv("skincare_cleaned.csv")  # place ton CSV à la racine de backend/
    df["price"] = df["price"].astype(str).str.replace("£", "").astype(float)
    df["probleme_peau"] = df["probleme_peau"].fillna("").astype(str)
    df["clean_ingreds"] = df["clean_ingreds"].fillna("")
    df["conseil_utilisation"] = df["conseil_utilisation"].fillna("")
except Exception as e:
    df = pd.DataFrame()
    print("Erreur de chargement du CSV :", e)

# ----------------- Modèle ML ------------------
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df["clean_ingreds"])
y = df["conseil_utilisation"]
model = LogisticRegression(max_iter=1000)
model.fit(X, y)

# ----------------- Pydantic Models ------------------
class RecommendRequest(BaseModel):
    type_peau: str
    age: int
    budget: float
    probleme_peau: List[str] = []

class ConseilRequest(BaseModel):
    index: int
    clean_ingreds_list: List[str]
    noms_produits: List[str]

# ----------------- Routes ------------------

@app.get("/")
def root():
    return {"message": "Backend GlowCare opérationnel ✅"}

@app.post("/recommend")
def recommend_products(req: RecommendRequest):
    filtered = df.copy()
    filtered = filtered[(filtered["type_peau"] == req.type_peau) | (filtered["type_peau"] == "tous")]
    filtered = filtered[(filtered["age_min"] <= req.age) & (filtered["age_max"] >= req.age)]
    filtered = filtered[filtered["price"] <= req.budget]

    if req.probleme_peau:
        filtered = filtered[filtered["probleme_peau"].apply(
            lambda x: any(p.lower() in x.lower() for p in req.probleme_peau)
        )]

    if filtered.empty:
        raise HTTPException(status_code=404, detail="Aucun produit trouvé.")

    produits = []
    for _, row in filtered.iterrows():
        if pd.notna(row["image_url"]):
            produits.append({
                "product_name": row["product_name"],
                "price": row["price"],
                "image_url": row["image_url"],
                "clean_ingreds": row["clean_ingreds"]
            })

    return {
        "nb_resultats": len(produits),
        "produits": produits
    }

@app.post("/conseil")
def get_conseil(req: ConseilRequest):
    index = req.index
    if index >= len(req.clean_ingreds_list):
        raise HTTPException(status_code=400, detail="Index invalide.")

    ingredients = req.clean_ingreds_list[index]
    nom = req.noms_produits[index]

    vect = vectorizer.transform([ingredients])
    prediction = model.predict(vect)[0]
    proba = model.predict_proba(vect).max()

    return {
        "product_name": nom,
        "conseil": prediction,
        "confiance": round(proba, 2)
    }

@app.get("/product/{product_name}")
def get_product(product_name: str):
    if df.empty:
        return JSONResponse({"error": "Données indisponibles"}, status_code=500)

    filtered = df[df["product_name"].str.lower().str.strip() == product_name.lower().strip()]
    if filtered.empty:
        return JSONResponse({"error": "Produit non trouvé"}, status_code=404)

    row = filtered.iloc[0]
    return {
        "Nom": row['product_name'],
        "Type": row['product_type'],
        "Prix": f"{row['price']} €",
        "Type de peau": row['type_peau'],
        "Problème": row['probleme_peau'],
        "Âge recommandé": f"{row['age_min']} - {row['age_max']} ans",
        "Voir le produit": row['product_url'],
        "Image": row['image_url']
    }

# ----------------- Lancer le serveur ------------------
if __name__ == "__main__":
    # Écoute sur le port 8000 en local
    uvicorn.run(app, host="0.0.0.0", port=8000)


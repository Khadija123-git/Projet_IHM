import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import RoutineForm from "./pages/RoutineForm";
import PerformancePage from "./pages/PerformancePage"; // ⬅️ à créer ensuite

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/routine" element={<RoutineForm />} />
        <Route path="/performance" element={<PerformancePage />} /> {/* ✅ nouvelle page */}
      </Routes>
    </Router>
  );
}

export default App;

import React, { useState } from 'react';
import './ChatWidget.css';
import avatar from '../assets/avatar.png';

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const [currentPage, setCurrentPage] = useState('home');
  const [productName, setProductName] = useState('');
  const [response, setResponse] = useState(null);
  const [skinType, setSkinType] = useState(null);

  const handleInputChange = (e) => setProductName(e.target.value);

  const handleSubmit = async () => {
    if (productName.trim() === '') return;

    try {
      const res = await fetch(`/product/${encodeURIComponent(productName)}`, { method: 'GET' });
      const text = await res.text();

      if (!res.ok) {
        console.error("❌ Erreur HTTP :", res.status, text);
        setResponse({ error: "Produit non trouvé ou serveur inaccessible." });
        return;
      }

      try {
        const data = JSON.parse(text);
        setResponse(data);
      } catch (parseError) {
        console.error("❌ Réponse non JSON :", text);
        setResponse({ error: "Réponse serveur invalide." });
      }
    } catch (fetchError) {
      console.error("❌ Erreur de requête JS :", fetchError);
      setResponse({ error: "Erreur réseau ou serveur inaccessible." });
    }
  };

  const handleOptionClick = (option) => {
    setCurrentPage(option);
    setResponse(null);
    setProductName('');
    setSkinType(null);

    if (option === 'motivation') {
      const messages = [
        "🌸 Tu es belle comme tu es 💖 Prends soin de ta peau avec amour ✨",
        "💪 Tu fais déjà de ton mieux, chaque geste compte 🧴✨",
        "🌞 Garde confiance en toi, ta peau mérite le meilleur 💕",
        "💧 Bois de l’eau, repose-toi, et surtout aime-toi 🫶",
        "🌿 Tu brilles de l’intérieur ✨ continue à t’épanouir 🌼"
      ];
      const random = messages[Math.floor(Math.random() * messages.length)];
      setResponse({ motivation: random });
    }
  };

  const handleCloseSubpage = () => {
    setCurrentPage('home');
    setResponse(null);
    setProductName('');
    setSkinType(null);
  };

  const getRoutineForSkinType = (type) => {
    const base = {
      'sèche': [
        { nom: "Gel nettoyant hydratant", moment: "matin et soir", frequence: "tous les jours" },
        { nom: "Sérum à l’acide hyaluronique", moment: "matin", frequence: "tous les jours" },
        { nom: "Crème nourrissante", moment: "soir", frequence: "tous les jours" },
        { nom: "Masque hydratant", moment: "soir", frequence: "2 fois / semaine" }
      ],
      'grasse': [
        { nom: "Gel nettoyant purifiant", moment: "matin et soir", frequence: "tous les jours" },
        { nom: "Toner sans alcool", moment: "matin", frequence: "tous les jours" },
        { nom: "Crème hydratante légère", moment: "soir", frequence: "tous les jours" },
        { nom: "Exfoliant BHA", moment: "soir", frequence: "2 fois / semaine" },
        { nom: "Masque à l’argile", moment: "soir", frequence: "1 fois / semaine" }
      ],
      'mixte': [
        { nom: "Gel nettoyant doux", moment: "matin et soir", frequence: "tous les jours" },
        { nom: "Lotion équilibrante", moment: "matin", frequence: "tous les jours" },
        { nom: "Crème hydratante équilibrante", moment: "soir", frequence: "tous les jours" },
        { nom: "Exfoliant doux", moment: "soir", frequence: "1 à 2 fois / semaine" }
      ],
      'sensible': [
        { nom: "Lait nettoyant apaisant", moment: "soir", frequence: "tous les jours" },
        { nom: "Sérum calmant (niacinamide)", moment: "matin", frequence: "tous les jours" },
        { nom: "Crème réparatrice", moment: "matin et soir", frequence: "tous les jours" },
        { nom: "Masque apaisant", moment: "soir", frequence: "1 fois / semaine" }
      ]
    };
    return base[type] || [];
  };

  const renderHome = () => (
    <div className="chat-options">
      <button onClick={() => handleOptionClick("produit")}>🔍 En savoir plus sur un produit</button>
      <button onClick={() => handleOptionClick("motivation")}>💡 Obtenir de la motivation</button>
      <button onClick={() => handleOptionClick("routine")}>🧴 Créer une routine complète</button>
      <button onClick={() => handleOptionClick("alerte")}>⚠️ Alerte sur les ingrédients incompatibles</button>
    </div>
  );

  const renderMotivation = () => (
    <div className="chat-subpage">
      <div className="subpage-header">
        <button className="back-button" onClick={() => setCurrentPage('home')}>← Retour</button>
        <button className="close-btn" onClick={handleCloseSubpage}>×</button>
      </div>
      <p className="bubble-text">{response?.motivation}</p>
    </div>
  );

const renderProduit = () => (
  <div className="chat-subpage">
    <div className="subpage-header">
      <button className="back-button" onClick={() => setCurrentPage('home')}>← Retour</button>
    </div>

    <div className="product-input">
      <p>Quel est le nom du produit que tu veux connaître&nbsp;?</p>
      <input
        type="text"
        placeholder="Ex&nbsp;: CeraVe Moisturising Cream 50ml"
        value={productName}
        onChange={handleInputChange}
      />
      <button onClick={handleSubmit}>Envoyer</button>
    </div>

    {response && (
      <div className="product-response">
        <div className="product-card">
          <button
            onClick={() => setResponse(null)}
            className="circle-close-btn"
            aria-label="Fermer"
          >
            ×
          </button>

          <p><strong>Nom :</strong> {response["Nom"]}</p>
          <p><strong>Type :</strong> {response["Type"]}</p>
          <p><strong>Prix :</strong> {response["Prix"]}</p>
          <p><strong>Type de peau :</strong> {response["Type de peau"]}</p>
          <p><strong>Problème :</strong> {response["Problème"]}</p>
          <p><strong>Âge recommandé :</strong> {response["Âge recommandé"]}</p>
          {response["Voir le produit"] && (
            <p>
              <strong>Lien :</strong>{" "}
              <a
                href={response["Voir le produit"]}
                target="_blank"
                rel="noopener noreferrer"
              >
                Voir le produit
              </a>
            </p>
          )}
          {response["Image"] && (
            <img
              src={response["Image"]}
              alt="Produit"
              style={{ maxWidth: '100%', borderRadius: '12px', marginTop: '12px' }}
            />
          )}
        </div>
      </div>
    )}
  </div>
);



  const renderRoutine = () => (
    <div className="chat-subpage">
      <div className="subpage-header">
        <button className="back-button" onClick={() => {
          setCurrentPage('home');
          setSkinType(null);
        }}>← Retour</button>
        <button className="close-btn" onClick={handleCloseSubpage}>×</button>
      </div>

      {!skinType ? (
        <>
          <p>Quel est ton type de peau&nbsp;?</p>
          <div className="chat-options" style={{ gap: '6px' }}>
            <button onClick={() => setSkinType('sèche')}>🌸 Sèche</button>
            <button onClick={() => setSkinType('grasse')}>💧 Grasse</button>
            <button onClick={() => setSkinType('mixte')}>🌗 Mixte</button>
            <button onClick={() => setSkinType('sensible')}>🍃 Sensible</button>
          </div>
        </>
      ) : (
        <div className="routine-card">
          <p><strong>Routine pour peau {skinType}</strong></p>
          <ul>
            {getRoutineForSkinType(skinType).map((step, i) => (
              <li key={i}>
                <strong>{step.nom}</strong> – {step.moment} – {step.frequence}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );

  const renderAlerte = () => (
    <div className="chat-subpage">
      <div className="subpage-header">
        <button className="back-button" onClick={() => setCurrentPage('home')}>← Retour</button>
        <button className="close-btn" onClick={handleCloseSubpage}>×</button>
      </div>
      <div style={{
        background: '#fff8f0',
        padding: '12px',
        borderRadius: '8px',
        color: '#a94442',
        fontSize: '14px',
        lineHeight: '1.6'
      }}>
        <p>
          ⚠️ <strong>Certains ingrédients actifs ne doivent pas être mélangés</strong> dans une même routine.
        </p>
        <ul style={{ marginTop: '8px', paddingLeft: '20px' }}>
          <li>🚫 Rétinol + Vitamine C</li>
          <li>🚫 AHA/BHA + Niacinamide</li>
          <li>🚫 Peroxyde de benzoyle + Vitamine C</li>
          <li>🚫 Rétinol + AHA/BHA</li>
          <li>🚫 Vitamine C + Peptides</li>
          <li>🚫 Acide salicylique + Acide glycolique</li>
          <li>🚫 Soufre + Peroxyde de benzoyle</li>
        </ul>
        <p style={{ marginTop: '12px' }}>
          ✨ Alterne ces actifs entre le matin et le soir ou choisis des soins complémentaires adaptés à ta peau.
        </p>
      </div>
    </div>
  );

  return (
    <div className="chatbot-container">
      <div className={`chatbox ${open ? 'open' : ''}`}>
        <div className="chat-header">
          <span>GlowCare • Chat Beauté</span>
          <button className="close-btn" onClick={() => setOpen(false)}>×</button>
        </div>

        <div className="chat-body">
          <img src={avatar} alt="chat-avatar" className="chat-avatar" />
          <p className="intro-text">
            Bonjour ! 💖 Besoin d’un conseil skincare ? <br />
            Je suis là pour t’aider ✨
          </p>

          {currentPage === 'home' && renderHome()}
          {currentPage === 'motivation' && renderMotivation()}
          {currentPage === 'produit' && renderProduit()}
          {currentPage === 'routine' && renderRoutine()}
          {currentPage === 'alerte' && renderAlerte()}
        </div>
      </div>

      <button className="chat-toggle" onClick={() => setOpen(!open)}>
        <img src={avatar} alt="Chatbot Toggle" />
      </button>
    </div>
  );
}








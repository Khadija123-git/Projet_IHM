import React from "react";
import { Link } from "react-router-dom";
import "./HomePage.css";

const HomePage = () => {
  return (
    <div
      style={{
        backgroundImage: `url(${process.env.PUBLIC_URL}/background.png)`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
        minHeight: "100vh",
      }}
    >
      <div className="background-overlay" />

      <div className="homepage">
        <h2 className="slogan animate-fade-in">🌸 La beauté commence par le soin de soi 🌸</h2>

        <div className="logo-circle animate-zoom-in">
          <span className="logo-text">GlowCare</span>
        </div>

        <p className="quote animate-fade-in-up">
          “L’éclat de votre peau commence avec une routine pensée juste pour vous.” – GlowCare ✨
        </p>

        <h3 className="about-title animate-fade-in">À propos de nous</h3>

        <div className="about-sections">
          <div className="about-card animate-zoom-in">
            <h4>💖 Notre mission</h4>
            <p>Nous proposons des recommandations personnalisées en matière de soins de la peau.</p>
          </div>
          <div className="about-card animate-zoom-in">
            <h4>🧪 Notre concept</h4>
            <p>Notre interface simplifie la recherche de produits adaptés à vos besoins.</p>
          </div>
          <div className="about-card animate-zoom-in">
            <h4>👩‍⚕️ Notre équipe</h4>
            <p>Nos spécialistes sont passionnés et vous guident avec douceur et expertise.</p>
          </div>
        </div>

        <Link to="/routine" className="cta-button animate-fade-in-up">
          ✨ Découvrir nos soins
        </Link>
      </div>
    </div>
  );
};

export default HomePage;

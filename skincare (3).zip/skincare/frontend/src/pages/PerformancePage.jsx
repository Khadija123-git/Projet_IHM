import React from "react";
import { PieChart, Pie, Cell, Tooltip, Legend } from "recharts";

const data = [
  { name: "Précision", value: 85 },
  { name: "Rappel", value: 80 },
  { name: "F1-Score", value: 82 },
];

const COLORS = ["#f2d5d0", "#e7bfb7", "#d8a39d"]; // 🌸 Douces couleurs

const PerformancePage = () => {
  return (
    <div
      style={{
        padding: "2rem",
        background: "#fdf7f2",
        minHeight: "100vh",
        fontFamily: "'Segoe UI', sans-serif",
      }}
    >
      <h2
        style={{
          fontFamily: "Great Vibes, cursive",
          fontSize: "2.5rem",
          color: "#5e4a4a",
          marginBottom: "2rem",
          textAlign: "center",
        }}
      >
        📊 Performance du Modèle
      </h2>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "2rem" }}>
        {/* 📉 Graphique à gauche */}
        <div style={{ flex: "1", display: "flex", justifyContent: "center" }}>
          <PieChart width={400} height={400}>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={120}
              fill="#8884d8"
              dataKey="value"
              label={({ name, value }) => `${name}: ${value}%`}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend verticalAlign="bottom" height={36} />
          </PieChart>
        </div>

        {/* 📝 Explication à droite */}
        <div
          style={{
            flex: "1",
            background: "#fff9f7",
            borderRadius: "1rem",
            padding: "1.5rem",
            boxShadow: "0 4px 12px rgba(0,0,0,0.05)",
            color: "#5e4a4a",
            lineHeight: "1.6",
          }}
        >
          <h3 style={{ marginBottom: "1rem", fontSize: "1.3rem" }}>📌 Comment lire ces résultats ?</h3>
          <p><strong>🔍 Précision :</strong> parmi les produits proposés, combien sont réellement adaptés ?</p>
          <p><strong>📈 Rappel :</strong> parmi tous les bons produits, combien ont été trouvés ?</p>
          <p><strong>🧠 F1-Score :</strong> équilibre entre précision et rappel (plus c’est haut, mieux c’est !).</p>
        </div>
      </div>
    </div>
  );
};

export default PerformancePage;


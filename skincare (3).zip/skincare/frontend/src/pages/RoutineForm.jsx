import React, { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import "./RoutineForm.css";
// Adaptez ce chemin si votre ChatWidget se trouve ailleurs
import ChatWidget from "../components/ChatWidget";

const RoutineForm = () => {
  const [typePeau, setTypePeau] = useState("");
  const [age, setAge] = useState("");
  const [budget, setBudget] = useState("");
  const [problemes, setProblemes] = useState([]);
  const [produits, setProduits] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [conseilProduit, setConseilProduit] = useState("");
  const [loading, setLoading] = useState(false);

  const carouselRef = useRef(null);
  const navigate = useNavigate();

  const handleCheckboxChange = (e) => {
    const value = e.target.value;
    setProblemes((prev) =>
      e.target.checked ? [...prev, value] : prev.filter((p) => p !== value)
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSelectedProduct(null);
    setConseilProduit("");
    setLoading(true);
    try {
      // Appel relatif vers /recommend — sera redirigé vers http://localhost:8000/recommend grâce au proxy
      const response = await fetch(`/recommend`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type_peau: typePeau,
          age: parseInt(age),
          budget: parseFloat(budget),
          probleme_peau: problemes,
        }),
      });

      if (!response.ok) {
        console.error("❌ Erreur HTTP (recommend) :", response.status);
        setProduits([]);
      } else {
        const data = await response.json();
        setProduits(Array.isArray(data.produits) ? data.produits : []);
      }
    } catch (error) {
      console.error("Erreur réseau (recommend) :", error);
      setProduits([]);
    }
    setLoading(false);
  };

  const fetchConseil = async (produit) => {
    try {
      setSelectedProduct(produit.product_name);
      // Appel relatif vers /conseil — sera redirigé vers http://localhost:8000/conseil grâce au proxy
      const res = await fetch(`/conseil`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          index: 0,
          clean_ingreds_list: [produit.clean_ingreds],
          noms_produits: [produit.product_name],
        }),
      });

      if (!res.ok) {
        console.error("❌ Erreur HTTP (conseil) :", res.status);
        setConseilProduit("");
      } else {
        const data = await res.json();
        setConseilProduit(data.conseil);
      }
    } catch (error) {
      console.error("Erreur réseau (conseil) :", error);
      setConseilProduit("");
    }
  };

  const scrollLeft = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollBy({ left: -300, behavior: "smooth" });
    }
  };

  const scrollRight = () => {
    if (carouselRef.current) {
      carouselRef.current.scrollBy({ left: 300, behavior: "smooth" });
    }
  };

  const handleNavigateToGraph = () => {
    navigate("/performance");
  };

  return (
    <div className="routine-form">
      {/* Titre */}
      <h1 className="main-title">Trouve ta routine skincare idéale ✨</h1>

      {/* Formulaire */}
      <div className="form-box">
        <form onSubmit={handleSubmit}>
          <label>Type de peau :</label>
          <select
            value={typePeau}
            onChange={(e) => setTypePeau(e.target.value)}
            required
          >
            <option value="">-- Sélectionner --</option>
            <option value="seche">Peau sèche</option>
            <option value="grasse">Peau grasse</option>
            <option value="mixte">Peau mixte</option>
            <option value="normale">Peau normale</option>
            <option value="tous">Tous types</option>
          </select>

          <label>Âge :</label>
          <input
            type="number"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            required
          />

          <label>Budget (£) :</label>
          <input
            type="number"
            value={budget}
            onChange={(e) => setBudget(e.target.value)}
            required
          />

          <label>Problèmes de peau :</label>
          <div className="checkbox-group">
            {[
              "acne",
              "rides",
              "rougeurs",
              "dryness",
              "taches",
              "pores",
              "peau sensible",
            ].map((p) => (
              <React.Fragment key={p}>
                <input
                  type="checkbox"
                  id={p}
                  value={p}
                  checked={problemes.includes(p)}
                  onChange={handleCheckboxChange}
                />
                <label htmlFor={p}>{p}</label>
              </React.Fragment>
            ))}
          </div>

          <button type="submit">✨ Voir ma routine</button>
        </form>
      </div>

      {/* Loader */}
      {loading && <div className="loader">Chargement en douceur... 🧴</div>}

      {/* Résultats */}
      {produits.length > 0 && (
        <section className="results-section">
          <h2 className="results-title">Voici les produits adaptés à ta peau ✨</h2>
          <div className="results-wrapper">
            <button className="arrow-button arrow-left" onClick={scrollLeft}>
              ⬅️
            </button>
            <div className="results" ref={carouselRef}>
              {produits.map((p, idx) => (
                <div key={idx} className="product-card">
                  <h3>{p.product_name}</h3>
                  <img src={p.image_url} alt={p.product_name} />
                  <button
                    className="conseil-button"
                    onClick={() => fetchConseil(p)}
                  >
                    💡 Voir le conseil
                  </button>
                  {selectedProduct === p.product_name && conseilProduit && (
                    <p className="beauty-quote">{conseilProduit}</p>
                  )}
                </div>
              ))}
            </div>
            <button className="arrow-button arrow-right" onClick={scrollRight}>
              ➡️
            </button>
          </div>
        </section>
      )}

      {/* Bouton vers la page performance */}
      <button className="performance-button" onClick={handleNavigateToGraph}>
        Voir les performances du modèle 📊
      </button>

      {/* Citation */}
      <p className="beauty-quote">
        La vraie beauté commence quand tu prends soin de toi.
      </p>

      {/* Chatwidget */}
      <ChatWidget />
    </div>
  );
};

export default RoutineForm;
